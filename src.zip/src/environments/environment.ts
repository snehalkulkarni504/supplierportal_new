export const environment = {

    ApiAdminService : "https://localhost:7122/AdminService/",
    ApiSupplierService : "https://localhost:7122/SupplierService/",
    ApiReportService : "https://localhost:7122/ReportService/"
    
};

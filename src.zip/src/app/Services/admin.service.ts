import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private httpClient: HttpClient) { }

  ApiUrl: any = environment.ApiAdminService;

  getMenu(id: any): Observable<any> {
    return this.httpClient.get<any[]>(this.ApiUrl + `GetMenu?id=${id}`);
  }

  getuserdetails() {
    return this.httpClient.get<any[]>(this.ApiUrl + 'Getusermaster');
  }

  getroles() {
    return this.httpClient.get<any[]>(this.ApiUrl + 'Getroles');
  }

  adduserdetails(user: any): Observable<any> {
    return this.httpClient.post<any>(this.ApiUrl + "Adduserdata", user);
  }

  updateuserdetails(data: any): Observable<any> {
    return this.httpClient.post<any>(this.ApiUrl + 'UpdateUserData', data);
  }

  Inactiveuser(userId: any) {
    return this.httpClient.post<any>(this.ApiUrl + 'DeleteUserData', userId);
  }

}

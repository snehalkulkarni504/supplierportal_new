import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {

  LoginForm!: FormGroup;
  Username: any;
  Password: any;
  UserId: any;
  results: any;

  constructor(public router: Router) {
  }

  ngOnInit(): void {
    this.LoginForm = new FormGroup({
      Username: new FormControl(),
      Password: new FormControl()
    });

    const si = document.getElementById("showicon") as HTMLElement;
    si.style.display = 'block';
    const hi = document.getElementById("hideicon") as HTMLElement;
    hi.style.display = 'none';
  }

  UserNameUp() {
    const myElement = document.getElementById("userlbl");
    myElement?.classList.remove("userlbl");
    myElement?.classList.remove("userlbldown");
    myElement?.classList.add("userlblup");
  }

  UserNameDown() {
    var user = this.Username;
    if (user == '' || user == undefined) {
      const myElement = document.getElementById("userlbl");
      myElement?.classList.remove("userlblup");
      myElement?.classList.add("userlbldown");
    }

  }

  PasswordUp() {
    const myElement = document.getElementById("pwdlbl");
    myElement?.classList.remove("userlbl");
    myElement?.classList.remove("userlbldown");
    myElement?.classList.add("userlblup");
  }

  PasswordDown() {
    var pwd = this.Password;
    if (pwd == '' || pwd == undefined) {
      const myElement = document.getElementById("pwdlbl");
      myElement?.classList.remove("userlblup");
      myElement?.classList.add("userlbldown");
    }
  }

  showPwd() {
    const myElement = document.getElementById("pwdtxt");
    myElement?.setAttribute('TYPE', 'TEXT');

    const si = document.getElementById("showicon") as HTMLElement;
    si.style.display = 'none';
    const hi = document.getElementById("hideicon") as HTMLElement;
    hi.style.display = 'block';
  }

  hidePwd() {
    const myElement = document.getElementById("pwdtxt");
    myElement?.setAttribute('TYPE', 'PASSWORD');

    const si = document.getElementById("showicon") as HTMLElement;
    si.style.display = 'block';
    const hi = document.getElementById("hideicon") as HTMLElement;
    hi.style.display = 'none';
  }

  async login() {

    this.router.navigate(['/dashboard']);
  }


}

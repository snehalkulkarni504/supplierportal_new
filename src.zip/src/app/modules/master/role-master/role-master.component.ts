import { Component } from '@angular/core';

@Component({
  selector: 'app-role-master',
  standalone: true,
  imports: [],
  templateUrl: './role-master.component.html',
  styleUrl: './role-master.component.css'
})
export class RoleMasterComponent {

}

import { Routes } from '@angular/router';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { POsupplierComponent } from './modules/posupplier/posupplier.component';

export const routes: Routes = [ 
    {
        path: '',
        loadChildren: () => import('./main/main.module').then(m => m.MainModule),
    },
];
 
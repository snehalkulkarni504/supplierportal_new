import { Component } from '@angular/core';

@Component({
  selector: 'app-posupplier',
  standalone: true,
  imports: [],
  templateUrl: './posupplier.component.html',
  styleUrl: './posupplier.component.css'
})
export class POsupplierComponent {

}

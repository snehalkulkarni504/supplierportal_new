import { Component } from '@angular/core';

@Component({
  selector: 'app-podetailsreport',
  standalone: true,
  imports: [],
  templateUrl: './podetailsreport.component.html',
  styleUrl: './podetailsreport.component.css'
})
export class PodetailsreportComponent {

}

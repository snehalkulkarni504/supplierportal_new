import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from '../modules/dashboard/dashboard.component';
import { POsupplierComponent } from '../modules/posupplier/posupplier.component';
import { UsermasterComponent } from '../modules/master/usermaster/usermaster.component';
import { RoleMasterComponent } from '../modules/master/role-master/role-master.component';
import { PodetailsreportComponent } from '../modules/report/podetailsreport/podetailsreport.component';


const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', redirectTo:'dashboard', pathMatch:'full'},
      { path: 'dashboard', component: DashboardComponent },
      { path: 'supplier', component:  POsupplierComponent },
      { path: 'user',component: UsermasterComponent},
      { path: 'role',component: RoleMasterComponent},
      { path: 'podetailsreport',component:PodetailsreportComponent}

    ]
  }

];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MainRoutingModule { }
